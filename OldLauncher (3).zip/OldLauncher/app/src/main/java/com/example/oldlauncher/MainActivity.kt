package com.example.oldlauncher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    // X is on the LEFT controller; grip = left grip (reported as L1 or L2, or as a trigger axis).
    private val gripKeys = setOf(KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_L2)
    private val lightningPackages = listOf("com.threethan.launcher", "com.threethan.launcher.lite")

    private var xHeld = false
    private var keyGrip = false
    private var axisGrip = false
    private var comboFired = false
    private var lastAxis = "none"

    private lateinit var info: TextView
    private lateinit var debug: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#14161A"))
            setPadding(64, 48, 64, 48)
        }
        info = TextView(this).apply {
            textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            text = "Hold X + left grip together\nto open Lightning Launcher"
        }
        debug = TextView(this).apply {
            textSize = 16f; setTextColor(Color.parseColor("#9AE6B4")); gravity = Gravity.CENTER
            text = "Press X and grip..."
        }
        val button = Button(this).apply {
            text = "Open Lightning Launcher"
            setOnClickListener { openLightning() }
        }
        root.addView(info); root.addView(debug); root.addView(button)
        setContentView(root)
    }

    private fun findLightning(): Intent? {
        for (pkg in lightningPackages) packageManager.getLaunchIntentForPackage(pkg)?.let { return it }
        // Fallback: any installed launchable app whose label contains "Lightning Launcher"
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        for (ri in packageManager.queryIntentActivities(main, 0)) {
            if (ri.loadLabel(packageManager).toString().contains("Lightning", ignoreCase = true) &&
                ri.activityInfo.packageName != packageName) {
                return packageManager.getLaunchIntentForPackage(ri.activityInfo.packageName)
            }
        }
        return null
    }

    private fun openLightning() {
        val intent = findLightning()
        if (intent == null) {
            info.text = "Lightning Launcher not found.\nInstall it first, then try again."
        } else {
            startActivity(intent)
        }
    }

    private fun updateStatus(last: String) {
        debug.text = "Last input: $last\nX held: $xHeld    Grip held: ${keyGrip || axisGrip} (key=$keyGrip axis=$axisGrip)\nAxes active: $lastAxis"
    }

    private fun checkCombo() {
        val gripHeld = keyGrip || axisGrip
        // Both must be held at the same moment.
        if (xHeld && gripHeld && !comboFired) {
            comboFired = true
            openLightning()
        }
        if (!xHeld || !gripHeld) comboFired = false
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val down = e.action == KeyEvent.ACTION_DOWN
        var handled = true
        when {
            e.keyCode == KeyEvent.KEYCODE_BUTTON_X -> xHeld = down
            e.keyCode in gripKeys -> keyGrip = down
            else -> handled = false
        }
        updateStatus("${KeyEvent.keyCodeToString(e.keyCode)} (${if (down) "down" else "up"})")
        checkCombo()
        return if (handled) true else super.dispatchKeyEvent(e)
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.source and InputDevice.SOURCE_JOYSTICK != 0 || e.source and InputDevice.SOURCE_GAMEPAD != 0) {
            val active = ArrayList<String>()
            for (axis in 0..48) {
                val v = e.getAxisValue(axis)
                if (kotlin.math.abs(v) > 0.5f) active.add("${MotionEvent.axisToString(axis)}=${"%.1f".format(v)}")
            }
            lastAxis = if (active.isEmpty()) "none" else active.joinToString(", ")
            axisGrip = e.getAxisValue(MotionEvent.AXIS_LTRIGGER) > 0.6f || e.getAxisValue(MotionEvent.AXIS_BRAKE) > 0.6f
            updateStatus("motion")
            checkCombo()
        }
        return super.dispatchGenericMotionEvent(e)
    }
}
