# Old Launcher (Quest 3S)

Open the folder in Android Studio, let Gradle sync, then Build > Build APK(s).
Install with: adb install -r app-debug.apk
Launch it from Library > Unknown Sources on the headset.

Controls
- X + left grip: switch between Library and Favorites
- Long-press an app: add/remove from Favorites
- Click an app: launch it

If the combo does nothing, look at the "Last key" line while pressing the grip.
Then edit `gripKeys` in MainActivity.kt to match the key it reports.
