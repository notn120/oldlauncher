package com.example.oldlauncher

import android.content.Context
import android.content.Intent

private val lightningPackages = listOf("com.threethan.launcher", "com.threethan.launcher.lite")

fun findLightningIntent(ctx: Context): Intent? {
    val pm = ctx.packageManager
    for (pkg in lightningPackages) pm.getLaunchIntentForPackage(pkg)?.let { return it }
    val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    for (ri in pm.queryIntentActivities(main, 0)) {
        if (ri.loadLabel(pm).toString().contains("Lightning", ignoreCase = true) &&
            ri.activityInfo.packageName != ctx.packageName) {
            return pm.getLaunchIntentForPackage(ri.activityInfo.packageName)
        }
    }
    return null
}
