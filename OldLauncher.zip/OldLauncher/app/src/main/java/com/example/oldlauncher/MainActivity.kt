package com.example.oldlauncher

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    // X button is on the LEFT controller; grip = left grip.
    // Quest may report grip as L1 or L2. Check the on-screen "Last key" line to see what yours sends.
    private val gripKeys = setOf(KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_L2)

    private var xHeld = false
    private var gripHeld = false
    private var comboFired = false
    private var showFavorites = false

    private lateinit var title: TextView
    private lateinit var debug: TextView
    private lateinit var grid: GridView
    private var allApps = listOf<ResolveInfo>()
    private val prefs by lazy { getSharedPreferences("fav", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#14161A"))
            setPadding(48, 32, 48, 32)
        }
        title = TextView(this).apply { textSize = 28f; setTextColor(Color.WHITE) }
        debug = TextView(this).apply { textSize = 14f; setTextColor(Color.GRAY) }
        grid = GridView(this).apply {
            numColumns = 6
            verticalSpacing = 24
            horizontalSpacing = 24
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
        }
        root.addView(title)
        root.addView(debug)
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        loadApps()
        refresh()
    }

    private fun loadApps() {
        val seen = HashSet<String>()
        val list = ArrayList<ResolveInfo>()
        for (cat in listOf(Intent.CATEGORY_LAUNCHER, "com.oculus.intent.category.VR", "com.oculus.intent.category.2D")) {
            val i = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in packageManager.queryIntentActivities(i, 0)) {
                if (ri.activityInfo.packageName != packageName && seen.add(ri.activityInfo.packageName)) list.add(ri)
            }
        }
        allApps = list.sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    private fun favorites() = prefs.getStringSet("pkgs", emptySet()) ?: emptySet()

    private fun refresh() {
        val favs = favorites()
        val shown = if (showFavorites) allApps.filter { it.activityInfo.packageName in favs } else allApps
        title.text = if (showFavorites) "Favorites" else "Library"
        grid.adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(p: Int) = shown[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                val ri = shown[p]
                return TextView(this@MainActivity).apply {
                    text = ri.loadLabel(packageManager)
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    maxLines = 2
                    setPadding(8, 16, 8, 16)
                    setCompoundDrawablesWithIntrinsicBounds(null, ri.loadIcon(packageManager), null, null)
                    compoundDrawablePadding = 8
                }
            }
        }
        grid.setOnItemClickListener { _, _, p, _ ->
            packageManager.getLaunchIntentForPackage(shown[p].activityInfo.packageName)?.let { startActivity(it) }
        }
        grid.setOnItemLongClickListener { _, _, p, _ ->
            val pkg = shown[p].activityInfo.packageName
            val set = favorites().toMutableSet()
            if (!set.add(pkg)) set.remove(pkg)
            prefs.edit().putStringSet("pkgs", set).apply()
            Toast.makeText(this, if (pkg in set) "Added to Favorites" else "Removed", Toast.LENGTH_SHORT).show()
            refresh()
            true
        }
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val down = e.action == KeyEvent.ACTION_DOWN
        debug.text = "Last key: ${KeyEvent.keyCodeToString(e.keyCode)} (${if (down) "down" else "up"})"
        when {
            e.keyCode == KeyEvent.KEYCODE_BUTTON_X -> xHeld = down
            e.keyCode in gripKeys -> gripHeld = down
            else -> return super.dispatchKeyEvent(e)
        }
        if (xHeld && gripHeld && !comboFired) {
            comboFired = true
            showFavorites = !showFavorites
            refresh()
        }
        if (!xHeld && !gripHeld) comboFired = false
        return true
    }
}
